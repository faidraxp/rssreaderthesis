package com.example.rssnewsreader.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.rssnewsreader.sqlite.DBHelper;

import java.util.List;

public class CategoriesDao {
    public static final String TAG = "CATEGORIESDAO";
    private SQLiteDatabase mDatabase;
    private DBHelper mDbHelper;
    private Context mContext;
//    private String[] mAllColumns={ DBHelper.COLUMN_CATEGORY ,
////            DBHelper.COLUMN_URL, DBHelper.COLUMN_TITLE,
////            DBHelper.COLUMN_LINK ,
////            DBHelper.COLUMN_AUTHOR,DBHelper.COLUMN_DESCRIPTION,DBHelper.COLUMN_IMAGE };


    public CategoriesDao(Context context) {//fix database

        this.mContext = context;
        mDbHelper = new DBHelper(context);
        // open the database
        try {
            open();
        } catch (SQLException e) {
            Log.e(TAG, "SQLException on opening database " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void open() throws SQLException {
        mDatabase = mDbHelper.getWritableDatabase();
    }

    public void close() {
        mDbHelper.close();
    }

    public boolean createCategories(List<String> categories,int feedId){
        boolean inserted=false;
        for(int i=0;i<=categories.size();i++){


            ContentValues values = new ContentValues();
            values.put(DBHelper.COLUMN_CATEGORY, categories.indexOf(i));
            values.put(DBHelper.COLUMN_RSS_FEED_ID, feedId);

            long result= mDatabase.insert(mDbHelper.TABLE_CATEGORIES,null,values);
            Log.e("DATABASE OPERATIONS", "Data inserted.");


            if (result == -1){
                inserted= false;
            }
            else {


                inserted= true;
            }



        }

        return inserted;

    }
    public String findFeedByID(int id){


        String query = "select title from " + mDbHelper.TABLE_CATEGORIES+"where id="+id;
        Cursor cursor = mDatabase.rawQuery(query, null);
        String category=cursor.getString(0);

        cursor.close();
        return category;
    }

    public void deleteCategories(){

        mDatabase.delete(mDbHelper.TABLE_CATEGORIES, null, null);

    }
}
