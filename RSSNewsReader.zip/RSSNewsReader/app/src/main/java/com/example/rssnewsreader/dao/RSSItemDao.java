package com.example.rssnewsreader.dao;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.rssnewsreader.rss.Μodel.Enclosure;
import com.example.rssnewsreader.rss.Μodel.Item;
import com.example.rssnewsreader.sqlite.DBHelper;

import java.util.ArrayList;


public class RSSItemDao {


    public static final String TAG = "RSSFEEDITEMDAO";
    private SQLiteDatabase mDatabase;
    private DBHelper mDbHelper;
    private Context mContext;

    //private String[] mAllColumns=


    public RSSItemDao(Context mContext) {
        this.mContext = mContext;

        mDbHelper = new DBHelper(mContext);
        // open the database
        try {
            open();
        } catch (SQLException e) {
            Log.e(TAG, "SQLException on opening database " + e.getMessage());
            e.printStackTrace();
        }
    }


    public void open() throws SQLException {
        mDatabase = mDbHelper.getWritableDatabase();
    }

    public void close() {
        mDbHelper.close();
    }

//to do categories find
    public boolean createItem(Item item,int feed_id){

        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_ITEM_TITLE, item.getTitle());
        values.put(DBHelper.COLUMN_PUBDATE, item.getPubDate());
        values.put(DBHelper.COLUMN_LINK, item.getLink());
        values.put(DBHelper.COLUMN_ITEM_AUTHOR,item.getContent() );
        values.put(DBHelper.COLUMN_GUID,item.getGuid() );
        values.put(DBHelper.COLUMN_ITEM_IMAGE,item.getEnclosure().getLink() );
        values.put(DBHelper.COLUMN_ITEM_DESCRIPTION,item.getDescription() );
        values.put(DBHelper.COLUMN_CONTENT,item.getContent() );
        values.put(DBHelper.COLUMN_THUMBNAIL, item.getContent() );


        long result=mDatabase.insert(mDbHelper.TABLE_RSS_ITEMS,null,values);
        Log.e("DATABASE OPERATIONS", "Data inserted.");
        if(item.getCategories()!=null){

            ContentValues cv=new ContentValues();

            for(int i=0;i<=item.getCategories().size();i++){

                cv.put(DBHelper.COLUMN_SUBCATEGORY_TITLE,item.getCategories().get(i));
                long catresult=mDatabase.insert(mDbHelper.TABLE_SUBCATEGORIES,null,cv);
            }



        }


        if (result == -1){
            return false;
        }
        else {


            return true;
        }

    }

    public void deleteItem(){

        mDatabase.delete(mDbHelper.TABLE_RSS_FEED, null, null);

    }


    public int findItemByID(int id){


        String query = "select id from " + mDbHelper.TABLE_RSS_ITEMS +"where id="+id;
        Cursor cursor = mDatabase.rawQuery(query, null);
        cursor.close();

        return -1;
    }


    public int findFeedByName(String title){


        String query = "select * from " +  mDbHelper.TABLE_RSS_ITEMS  +"where title="+title;
        Cursor cursor = mDatabase.rawQuery(query, null);

        int id=cursor.getInt(0);

        cursor.close();

        return id;
    }

    public ArrayList<Item> selectAll(){



        ArrayList<Item> allList = new ArrayList<>();
        String query = "select * from " + mDbHelper.TABLE_RSS_ITEMS;

        Cursor cursor = mDatabase.rawQuery(query, null);
        //cursor.moveToFirst();

        while (cursor.moveToNext()) {

            Item data=new Item();
            Enclosure enclosure=new Enclosure();
            data.setId(cursor.getInt(0));
            data.setPubDate(cursor.getString(1));
            data.setLink(cursor.getString(2));
            data.setAuthor(cursor.getString(3));
            data.setContent(cursor.getString(1));
            data.setDescription(cursor.getString(7));
            data.setGuid(cursor.getString(4));
            data.setThumbnail(cursor.getString(9));
            data.setContent(cursor.getString(8));
            enclosure.setLink(cursor.getString(6));
            data.setEnclosure(enclosure);


          allList.add(data);
        }

        cursor.close();
        return allList;


    }
}
