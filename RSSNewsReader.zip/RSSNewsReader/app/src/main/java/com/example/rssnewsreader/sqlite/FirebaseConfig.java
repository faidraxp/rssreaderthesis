package com.example.rssnewsreader.sqlite;

import android.util.Log;

import com.example.rssnewsreader.rss.Μodel.DataInitialize;
import com.example.rssnewsreader.userprofile.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirebaseConfig {

    static  String TAG="FIREBASE APP TEST";
    private DatabaseReference  mDatabase ;
    public void addUser(User user){

        mDatabase = FirebaseDatabase.getInstance().getReference();
        if(user.getFbID()!=null){

        }
        mDatabase.child("users").child(user.getFbID().toString()).setValue(user);

    }

    public void addResources(DataInitialize data){

        mDatabase = FirebaseDatabase.getInstance().getReference();

    }
    public void config(){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");

        // Write a message to the database
        myRef.setValue("Hello, World v.2!");
    }
//    public void getData(){
//        DatabaseReference myRef = database.getReference("message");
//
//        // Read from the database
//        myRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                // This method is called once with the initial value and again
//                // whenever data at this location is updated.
//                String value = dataSnapshot.getValue(String.class);
//                Log.d(TAG, "Value is: " + value);
//            }
//
//            @Override
//            public void onCancelled(DatabaseError error) {
//                // Failed to read value
//                Log.w(TAG, "Failed to read value.", error.toException());
//            }
//        });
//    }

}
