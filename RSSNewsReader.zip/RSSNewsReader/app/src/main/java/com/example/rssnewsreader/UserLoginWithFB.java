package com.example.rssnewsreader;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.rssnewsreader.sqlite.FirebaseConfig;
import com.example.rssnewsreader.userprofile.User;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;


public class UserLoginWithFB extends AppCompatActivity {
public static String TAG="USER LOGIN FB";

    CallbackManager callbackManager = CallbackManager.Factory.create();
    FirebaseConfig config;

    private static final String EMAIL = "email";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login_with_fb);
        checkLogin();
        Log.d(TAG,"apptest 1");
        LoginManager.getInstance().registerCallback(callbackManager,
                new FacebookCallback<LoginResult>() {
                    @Override
                    public void onSuccess(LoginResult loginResult) {
                        Log.d(TAG,"apptest 3"+loginResult);
                        AccessToken accessToken = AccessToken.getCurrentAccessToken();
                        GraphRequest graphRequest=GraphRequest.newMeRequest(accessToken, new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                User user=new User();
                                config=new FirebaseConfig();
                                //config.addUser(user);
                                config.config();


                                try {
                                    user.setName(object.getString("name"));
                                    user.setFbID(Long.parseLong(object.getString("id")));
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });

                        Bundle parameters=new Bundle();
                        parameters.putString("fields", "id,name,link,age_range,email");
                        graphRequest.setParameters(parameters);
                        graphRequest.executeAsync();
                        Log.v(TAG,"apptest 4 "+graphRequest);
                        Log.v(TAG,"apptest 5 "+parameters);


                        //LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile"));

                    }

                    @Override
                    public void onCancel() {
                        // App code
                        Log.d(TAG,"cancel");
                    }

                    @Override
                    public void onError(FacebookException exception) {
                        // App code
                        Log.d(TAG,"error");
                    }
                });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG,"apptest 2");
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void checkLogin(){

        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        boolean isLoggedIn = accessToken != null && !accessToken.isExpired();
        if(isLoggedIn==true){
            Log.d(TAG,"is logged in");
//            Intent intent = new Intent(this, SearchDialog.class);
//            startActivity(intent);
//            finish();

        }

    }

}
