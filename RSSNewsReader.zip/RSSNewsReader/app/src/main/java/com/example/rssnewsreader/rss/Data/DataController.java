package com.example.rssnewsreader.rss.Data;

public class DataController {


}
