package com.example.rssnewsreader;

import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.rssnewsreader.rss.Μodel.DataInitialize;

public class AddRecources extends AppCompatActivity {
    Toolbar toolbar;
    Button button;
    TextInputLayout siteName;
    TextInputLayout siteUrl;
    static String TAG="ADD RESOURCES";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recources);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Add New Resources");
        setSupportActionBar(toolbar);

        button=findViewById(R.id.button2);
        siteName=findViewById(R.id.sitename);
        siteUrl=findViewById(R.id.siteurl);

    }
    public void onClick(View view){
        DataInitialize data=new DataInitialize();
        data.setLink(siteUrl.getEditText().getText().toString());
        data.setSearchName(siteName.getEditText().getText().toString());
        Toast.makeText(this,"it's clicked"+data+TAG,Toast.LENGTH_LONG).show();
    }


}
