package com.example.rssnewsreader.userprofile;

import java.io.Serializable;

public class User implements Serializable {

    Long fbID;
    String gender;
    String age;
    String name;

    public User() {
    }

    public Long getFbID() {
        return fbID;
    }

    public void setFbID(Long fbID) {
        this.fbID = fbID;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
