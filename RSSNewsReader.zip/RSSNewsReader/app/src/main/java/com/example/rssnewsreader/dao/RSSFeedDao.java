package com.example.rssnewsreader.dao;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.rssnewsreader.rss.Μodel.Feed;
import com.example.rssnewsreader.sqlite.DBHelper;

public class RSSFeedDao {


    public static final String TAG = "RSSFEEDDAO";

    // Database fields
    private SQLiteDatabase mDatabase;
    private DBHelper mDbHelper;
    private Context mContext;
    private String[] mAllColumns={ DBHelper.COLUMN_FEED_ID,
            DBHelper.COLUMN_URL, DBHelper.COLUMN_TITLE,
            DBHelper.COLUMN_LINK ,
            DBHelper.COLUMN_AUTHOR,DBHelper.COLUMN_DESCRIPTION,DBHelper.COLUMN_IMAGE };

    public RSSFeedDao(Context context) {//fix database

        this.mContext = context;
        mDbHelper = new DBHelper(context);
        // open the database
        try {
            open();
        } catch (SQLException e) {
            Log.e(TAG, "SQLException on opening database " + e.getMessage());
            e.printStackTrace();
        }
    }
    public void open() throws SQLException {
        mDatabase = mDbHelper.getWritableDatabase();
    }

    public void close() {
        mDbHelper.close();
    }

    public boolean createFeed(Feed feed){

        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_URL, feed.getUrl());
        values.put(DBHelper.COLUMN_TITLE, feed.getTitle());
        values.put(DBHelper.COLUMN_LINK, feed.getLink());
        values.put(DBHelper.COLUMN_AUTHOR,feed.getAuthor() );
        values.put(DBHelper.COLUMN_DESCRIPTION,feed.getDescription() );
        values.put(DBHelper.COLUMN_IMAGE,feed.getImage() );

        long result=mDatabase.insert(mDbHelper.TABLE_RSS_FEED,null,values);
        Log.e("DATABASE OPERATIONS", "Data inserted.");


        if (result == -1){
            return false;
        }
        else {


            return true;
        }

    }

    public void deleteFeed(){

        mDatabase.delete(mDbHelper.TABLE_RSS_FEED, null, null);

    }

    public Feed findFeedByID(int id){


        String query = "select * from " + mDbHelper.TABLE_RSS_FEED+"where id="+id;
        Cursor cursor = mDatabase.rawQuery(query, null);

        Feed data =new Feed();
        data.setId(cursor.getInt(0));
        data.setUrl(cursor.getString(1));
        data.setTitle(cursor.getString(2));
        data.setLink(cursor.getString(3));
        data.setAuthor(cursor.getString(4));
        data.setDescription(cursor.getString(5));
        data.setImage(cursor.getString(6));

        cursor.close();

        return data;
    }

    public Feed findFeedByName(String title){


        String query = "select * from " + mDbHelper.TABLE_RSS_FEED+"where title="+title;
        Cursor cursor = mDatabase.rawQuery(query, null);

        Feed data =new Feed();
        data.setId(cursor.getInt(0));
        data.setUrl(cursor.getString(1));
        data.setTitle(cursor.getString(2));
        data.setLink(cursor.getString(3));
        data.setAuthor(cursor.getString(4));
        data.setDescription(cursor.getString(5));
        data.setImage(cursor.getString(6));

        cursor.close();

        return data;
    }

    public Feed findFeedByURL(String url){


        String query = "select * from " + mDbHelper.TABLE_RSS_FEED+"where url="+url;
        Cursor cursor = mDatabase.rawQuery(query, null);
        Feed data =new Feed();
        data.setId(cursor.getInt(0));
        data.setUrl(cursor.getString(1));
        data.setTitle(cursor.getString(2));
        data.setLink(cursor.getString(3));
        data.setAuthor(cursor.getString(4));
        data.setDescription(cursor.getString(5));
        data.setImage(cursor.getString(6));
        cursor.close();
        return data ;
    }

    public ArrayList<Feed> selectAll(){



        ArrayList<Feed> allList = new ArrayList<>();
        //String query = "select * from " + activities_table +"having DATE("+tb_tmstamp+")=CURDATE();" ;
        String query = "select * from " + mDbHelper.TABLE_RSS_FEED;

        Cursor cursor = mDatabase.rawQuery(query, null);
        //cursor.moveToFirst();

        while (cursor.moveToNext()) {

            Feed data =new Feed();
            data.setId(cursor.getInt(0));
            data.setUrl(cursor.getString(1));
            data.setTitle(cursor.getString(2));
            data.setLink(cursor.getString(3));
            data.setAuthor(cursor.getString(4));
            data.setDescription(cursor.getString(5));
            data.setImage(cursor.getString(6));

            allList.add(data);
        }

        cursor.close();
        return allList;


    }



}
