package com.example.rssnewsreader.ui.main;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.rssnewsreader.R;
import com.example.rssnewsreader.rss.Adapter.FeedAdapter;
import com.example.rssnewsreader.rss.Interface.ItemClickListener;
import com.example.rssnewsreader.rss.Μodel.RSSObject;

public class RecommendedFragment  extends Fragment implements ItemClickListener {
    private View view;
    RecyclerView recyclerView;
    RSSObject rssObject;
    public static String TAG = "FRAGMENT RECOMMENDED ACTIVITY";
    public RecommendedFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        view= inflater.inflate(R.layout.fragment_recommended, container, false);
        return view;
    }
    @Override
    public void onClick(View view, int position) {
        Log.d(TAG, "rss item clicked" + position);
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(rssObject.getItems().get(position).getLink()));
        startActivity(browserIntent);
    }
    public void createRecyclerView(RSSObject rssObject, Context context) {
        FeedAdapter adapter = new FeedAdapter(rssObject, context, this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }
}
