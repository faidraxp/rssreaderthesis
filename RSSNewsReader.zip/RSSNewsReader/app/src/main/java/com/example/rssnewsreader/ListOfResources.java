package com.example.rssnewsreader;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;

import com.example.rssnewsreader.rss.Adapter.RecourcesAdapter;
import com.example.rssnewsreader.rss.Interface.ItemClickListener;
import com.example.rssnewsreader.rss.Μodel.DataInitialize;

import java.util.ArrayList;
import java.util.List;

public class ListOfResources extends AppCompatActivity implements ItemClickListener {
    Toolbar toolbar;
    RecyclerView recyclerView;
    static String TAG="ListOfResources";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_resources);
        toolbar =  findViewById(R.id.toolbar);
        toolbar.setTitle("List of Resources");
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getBaseContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);

        List<DataInitialize> list=createLists();
        setAdapter(list,getBaseContext());

    }
    public List<DataInitialize> createLists(){
        List<DataInitialize> list=new ArrayList<DataInitialize>();
        DataInitialize link1=new DataInitialize();
        DataInitialize link2=new DataInitialize();
        DataInitialize link3=new DataInitialize();

        link1.setSearchName("science");
        link2.setSearchName("news");
        link3.setSearchName("Sports");

        link1.setLink("www.science.gr");
        link2.setLink("www.news.gr");
        link3.setLink("www.sports.gr");

        list.add(link1);
        list.add(link2);
        list.add(link3);

        return list;
    }

    public void setAdapter(List<DataInitialize> list,Context context){
        RecourcesAdapter adapter=new RecourcesAdapter(list,context,this);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(View view, int position) {
        Log.d(TAG,"test");
    }
}
